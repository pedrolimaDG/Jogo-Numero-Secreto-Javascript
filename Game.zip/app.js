let maximoTentativas = 0
//let reset = document.querySelector('input').value;

function limparCampo() {
    let reset = document.querySelector('input');
    reset.value = '';
}

if (maximoTentativas == 0) {
    setup();
}

function setup() {
    console.log('entrou no if inicial');
    exibirTextoNaTela('h1' , 'Bem-vindo');
    exibirTextoNaTela('p' , 'Escolha com quantos numeros deseja jogar!');
    document.getElementById('setup').addEventListener('click', configurarMaximo, false);
    
    
}

function trocarIdChutar() {
    var elemento = document.getElementById('setup');
    elemento.id = 'chutar'; // Troca o ID do elemento
    console.log('ID trocado para:', elemento.id);
}

function exibirTextoNaTela(tag, texto) {
    let campo = document.querySelector(tag);
    campo.innerHTML = texto;
}

function configurarMaximo() {
    maximoTentativas = document.querySelector('input').value;
    console.log(`maximo de tentativas = ${maximoTentativas}`);
    document.getElementById('setup').removeEventListener('click', configurarMaximo, false);
    limparCampo();
    trocarIdChutar();
    gameStart();
    return maximoTentativas;
}

let listaDeNumerosSorteados = [];

function gameStart() {
    document.getElementById('chutar').addEventListener('click', verificarChute, false);
    document.getElementById('chutar').innerHTML = 'Chutar';
    let numeroSecreto = gerarNumeroAleatorio();
    let mensagemInicial = `Escolha um numero entre 1 e ${maximoTentativas}`;
    
    function exibirMensagemInicial() {
        exibirTextoNaTela('h1' , 'Jogo do número secreto');
        exibirTextoNaTela('p' , mensagemInicial);
    }
    
    exibirMensagemInicial();
    
    let contarChute = 1;

    document.getElementById('chutar').addEventListener('click', verificarChute, false);

    function verificarChute() {
        console.log(`contarChute = ${contarChute}`);
        let chute = document.querySelector('input').value;
        let palavra = contarChute > 1 ? 'tentativas' : 'tentativa';
        let mensagemTentativas = `Você acertou em ${contarChute} ${palavra}!`;
        if (chute == numeroSecreto) {
            exibirTextoNaTela('h1' , 'Você acertou!');
            exibirTextoNaTela('p' , mensagemTentativas);
            document.getElementById('reiniciar').removeAttribute('disabled');
            document.getElementById('chutar').setAttribute('disabled',true);
            document.getElementById('chutar').removeEventListener('click', verificarChute, false);
        } else if (chute > numeroSecreto) {
                contarChute++;
                let mensagemErro = `Tentativa ${contarChute}`;
                exibirTextoNaTela('h1' , mensagemErro);
                exibirTextoNaTela('p' , 'O Número Secreto é Menor');
                limparCampo();
            } else {
                contarChute++;
                let mensagemErro = `Tentativa ${contarChute}`;
                exibirTextoNaTela('h1' , mensagemErro);
                exibirTextoNaTela('p' , 'O Número Secreto é Maior');
                limparCampo();
            }
    }
    
    function gerarNumeroAleatorio() {
        let numeroEscolhido = parseInt(Math.random() * maximoTentativas + 1);
        if (listaDeNumerosSorteados.includes(numeroEscolhido)) {
            return gerarNumeroAleatorio();
        } else {
            listaDeNumerosSorteados.push(numeroEscolhido);
            return numeroEscolhido;
        }
    }
}

function reiniciarJogo() {
    contarChute = 1;
    limparCampo();
    document.getElementById('reiniciar').setAttribute('disabled',true);
    document.getElementById('chutar').removeAttribute('disabled');
    if (listaDeNumerosSorteados.length == maximoTentativas) {
        listaDeNumerosSorteados = [];
    }

    function trocarIdSetup() {
        var elemento = document.getElementById('chutar');
        elemento.id = 'setup'; // Troca o ID do elemento
        console.log('ID trocado para:', elemento.id);
    }
    document.getElementById('chutar').innerHTML = 'Iniciar';
    trocarIdSetup();
    setup();
}